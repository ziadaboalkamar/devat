
<?php $__env->startSection('title','التفاصيل'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0">تفاصيل مستفيد</h2>
                            <div class="breadcrumb-wrapper">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">الرئيسية</a>
                                    </li>
                                    <li class="breadcrumb-item"><a href="#">المستفيدين</a>
                                    </li>
                                    <li class="breadcrumb-item active">تفاصيل مستفيد
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="content-body">
                <!-- Input Mask start -->
                <section id="input-mask-wrapper">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">عرض التفاصيل مستفيد</h4>
                                </div>
                                <div class="card-body">
                                    <div class="tab-content">
                                        <div class="tab-pane fade active show" id="home-02" role="tabpanel"
                                            aria-labelledby="home-02-tab">

                                            <div class="row">
                                                <div class="col-lg-4 col-md-6 border-right-2 border-right-blue-400">
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('الاسم الاول')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->firstName); ?> </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('اسم الاب')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->secondName); ?> </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('اسم الجد')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->thirdName); ?> </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('اسم العائلة')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->lastName); ?> </label>
                                                        </div>
                                                    </div>
                                                                                
                                                   
                                                                                
                                                             
                                                </div>
                                                <div class="col-lg-4 col-md-6 border-right-2 border-right-blue-400">
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('الجنس')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->gender); ?> </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('رقم الهوية')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->id_number); ?> </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('رقم الهاتف')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->PhoneNumber); ?> </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('عدد افراد الاسرة')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->family_member); ?> </label>
                                                        </div>
                                                    </div>
                                                                                
                                                   
                                                                                
                                                             
                                                </div>
                                                <div class="col-lg-4 col-md-6 border-right-2 border-right-blue-400">
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('اسم الفرع')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->branchs->name); ?> </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('اسم المدينة')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->cities->city_name); ?> </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('العنوان')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->address); ?> </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('الحالة الاجتماعية')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->maritial); ?> </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-lg-4 col-form-label font-weight-semibold"><?php echo e(__('الحالة ')); ?></label>
                                                        <div class="col-lg-8">
                                                            <label class="col-lg-12 col-form-label font-weight-semibold"><?php echo e($beneficiary->getActive()); ?> </label>
                                                        </div>
                                                    </div>
                                                                                
                                                </div>
                                            </div>
                                            <hr>
                                            <a href="<?php echo e(route('beneficiareis.index')); ?>" class="btn btn-outline-secondary">اغلاق</a>
                                        </div>
            
                                       
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ديفات\devat\resources\views/dashboard/pages/beneficiareis/show.blade.php ENDPATH**/ ?>