<!-- Modal -->
<div class="modal fade" id="update_status<?php echo e($beneficiary->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">
                    تغيير الحالة</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('update_status')); ?>" method="post" autocomplete="off">
                <?php echo e(csrf_field()); ?>

                <div class="modal-body">

                    <div class="form-group">
                        <label for="status"><?php echo e(__('Status')); ?></label>
                        <select class="form-control" id="status" name="status_id" required>
                            <option value="" selected disabled>--<?php echo e(__('اختر')); ?>--</option>
                            <option value="1" <?php echo e(old('status_id',$beneficiary->status_id) == 1 ? 'selected' : null); ?>>فعال</option>
                            <option value="0" <?php echo e(old('status_id',$beneficiary->status_id) == 0 ? 'selected' : null); ?>>غير فعال</option>
                        </select>
                    </div>
                </div>
                <input type="hidden" name="id" value="<?php echo e($beneficiary->id); ?>">

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-dismiss="modal"><?php echo e(__('الغاء')); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo e(__('حفظ')); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\ديفات\devat\resources\views/dashboard/pages/beneficiareis/updateStatus.blade.php ENDPATH**/ ?>